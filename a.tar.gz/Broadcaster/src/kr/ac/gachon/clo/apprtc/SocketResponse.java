package kr.ac.gachon.clo.apprtc;

public class SocketResponse {

	public static final int SUCCESS = 0;

	public static final int FAILURE = 1;

	private SocketResponse() {}
}
